## 패키지 불러오기 ##
library(dplyr)
library(ggplot2)

# 3. dplyr

## 3.1 파이프 연산자
x <- 1:10

sum(x)

x %>% 
  sum()

## 3.2 select()
select(diamonds, carat, price)


diamonds %>% 
  select(carat, price)

diamonds %>% 
  select(c(carat, price))

diamonds %>% 
  select(1, 7)

diamonds %>% 
  select(starts_with("c"))

diamonds %>% 
  select(contains("l"))

diamonds %>% 
  select(-carat, -price)

## 3.3 filter()
filter(diamonds, cut == "Ideal")

diamonds %>% 
  filter(cut == "Ideal")

diamonds %>% 
  filter(cut %in% c("Ideal", "Good"))

diamonds %>%
  filter(price >= 1000)     

diamonds %>% 
  filter(price != 1000)

diamonds %>% 
  filter(carat > 3 & price < 14000)

diamonds %>% 
  filter(carat < 1 | carat > 5)


## 3.4 silce()
diamonds %>% 
  slice(1:5)

diamonds %>% 
  slice(c(1:5, 8, 15:20))

diamonds %>% 
  slice(-1)

## 3.5 mutate()
diamonds %>% 
  mutate(price/carat)

diamonds %>% 
  select(carat, price) %>% 
  mutate(price/carat)

diamonds %>% 
  select(carat, price) %>% 
  mutate(Ratio = price/carat)

diamonds %>% 
  select(carat, price) %>% 
  mutate(Ratio = price/carat,
         Double = Ratio*2)

dia_ratio <- diamonds %>% 
  select(carat, price) %>% 
  mutate(Ratio = price/carat,
         Double = Ratio*2)

## 3.6 summarize()
diamonds %>% 
  summarize(mean(price))

diamonds %>% 
  summarize(AvgPrice = mean(price),
            MedianPrice = median(price),
            Avgcarat = mean(carat))

diamonds %>% 
  summarise(across(c(price, carat),
            list(mean = ~mean(.x),
                 median = ~median(.x)
                 ),
            .names ="{.col}-{.fn}"))

## 3.7 group_by()
mean(diamonds[diamonds$cut == "Fair", ]$price)
mean(diamonds[diamonds$cut == "Good", ]$price)
mean(diamonds[diamonds$cut == "Very Good", ]$price)
mean(diamonds[diamonds$cut == "Premium", ]$price)
mean(diamonds[diamonds$cut == "Ideal", ]$price)

diamonds %>% 
  group_by(cut) %>% 
  summarize(AvgPrice = mean(price))

diamonds %>% 
  group_by(cut, color) %>% 
  summarize(AvgPrice = mean(price), SumCarat = sum(carat))

diamonds %>% 
  group_by(cut, color) %>% 
  summarize(AvgPrice = mean(price), SumCarat = sum(carat)) %>% 
  filter(cut == "Fair")

## 3.8 arrange()
diamonds %>% 
  group_by(cut) %>% 
  summarize(AvgPrice = mean(price), SumCarat = sum(carat)) %>% 
  arrange(AvgPrice)

diamonds %>% 
  group_by(cut) %>% 
  summarize(AvgPrice = mean(price), SumCarat = sum(carat)) %>% 
  desc(AvgPrice)

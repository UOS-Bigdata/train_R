## 패키지 불러오기 ##
library(tidyverse) 
library(lubridate) 
library(stringr) 
library(readxl) 
library(flextable) 
library(here) 
library(showtext)
font_add_google("Nanum Pen Script", "gl")
showtext_auto()


# 5. 국민체력 100 자료를 이용한 데이터 분석 예제
df_data <- read_xlsx(here("data", "sample_data_sports100.xlsx"), col_names = TRUE)
df_col_info <- read_xlsx(here("data", "column_info.xlsx"), col_names = TRUE)
df_class_level <- read_xlsx(here("data", "class_level.xlsx"), col_names = TRUE)

head(df_data)

head(df_col_info)

head(df_class_level)

## 데이터 전처리
glimpse(df_data)

df_data <- df_data %>%
  mutate(TEST_AGE = as.integer(TEST_AGE))

glimpse(df_data$TEST_MD)

df_data <- df_data %>%
  mutate(TEST_MD = ymd(TEST_MD))

glimpse(df_data$TEST_MD)

df_data <- df_data %>%
  mutate(TEST_YEAR = factor(year(TEST_MD))) %>%
  relocate(TEST_YEAR, .after = TEST_MD)

df_data <- df_data %>%
  mutate(TEST_SEX = case_when(
    TEST_SEX == "M" ~ "남성", 
    TEST_SEX == "F" ~ "여성")) %>% 
  mutate(TEST_SEX = factor(TEST_SEX, levels = c("남성", "여성"))) %>%
  mutate(AGE_GBN = factor(AGE_GBN, levels = c("청소년", "성인",  "어르신")))

glimpse(df_data)

## 기술 통계 분석
table(df_data$TEST_YEAR)
table(df_data$TEST_SEX)
table(df_data$AGE_GBN)

table(df_data$TEST_SEX, df_data$TEST_YEAR)
as.data.frame(table( df_data$TEST_SEX, df_data$TEST_YEAR))

cross_tbl_01 <- df_data %>%
  group_by(TEST_YEAR, TEST_SEX) %>%
  summarise(n = n(), .groups = "drop_last") %>%
  mutate(percent = n / sum(n) * 100 ) 

cross_tbl_01

cross_tbl_02 <- df_data %>%
  group_by(TEST_YEAR, TEST_SEX) %>%
  summarise( n = n(), .groups = "drop") %>%
  mutate( percent = n / sum(n) * 100 ) 

cross_tbl_02

## 연속형 자료의 요약
summary_stats_1 <- df_data %>%
  group_by(TEST_YEAR, TEST_SEX) %>%
  summarise(
    height_mean = mean(ITEM_F001, na.rm = TRUE),
    height_sd = sd(ITEM_F001, na.rm = TRUE), 
    .groups = "keep")

summary_stats_1

summary_stats_2 <- df_data %>%
  group_by(TEST_YEAR, TEST_SEX) %>%
  summarise(
    across(c(ITEM_F001, ITEM_F002, ITEM_F003), 
           list(mean = ~ mean(.x, na.rm = TRUE),
                sd = ~ sd(.x, na.rm = TRUE),
                min = ~ min(.x, na.rm = TRUE),
                max = ~ max(.x, na.rm = TRUE)
           ),
           .names = "{.col}-{.fn}"
    ),
    .groups = "keep"
  )

summary_stats_2

head(summary_stats_2, 20) %>%
  flextable() %>%
  autofit()

## 자료의 형태 변환
summary_stats_3 <- summary_stats_2 %>%
  pivot_longer(
    cols = starts_with("ITEM"),
    names_sep = "-", 
    names_to = c("varname_eng", "stat"),
    values_to = "value"
  )

head(summary_stats_3, 20) %>%
  flextable() %>%
  autofit()

df_var_names <- df_col_info %>%
  select( varname_eng , varname_kor)

summary_stats_4 <- summary_stats_3 %>%
  left_join( df_var_names,
             by = "varname_eng")

head(summary_stats_4, 20) %>%
  flextable() %>%
  autofit()


summary_stats_5 <- summary_stats_4 %>%
  select( -varname_eng) %>%
  relocate( varname_kor, .before = stat) 

head(summary_stats_5, 20) %>%
  flextable() %>%
  autofit() 

final_summary_stats <- summary_stats_5 %>%
  mutate(stat = case_match( stat, 
                             "mean" ~ "평균",
                             "sd" ~ "표준편차",
                             "min" ~ "최소값",
                             "max" ~ "최대값")) 

head(final_summary_stats, 20) %>%
  flextable() %>%
  autofit() 

final_summary_stats <- final_summary_stats %>%
  rename( 년도 = TEST_YEAR,
          성별 = TEST_SEX,
          측정항목 = varname_kor,
          통계량 = stat,
          값 = value)

head(final_summary_stats, 20) %>%
  flextable() %>%
  autofit() 

final_summary_mean <- final_summary_stats %>%
  filter( 통계량 == "평균") %>%
  arrange( 성별, 측정항목, 년도, 통계량) %>%
  relocate( 성별, .before = 년도) %>%
  relocate( 측정항목, .before = 년도 ) 

head(final_summary_mean, 20) %>%
  flextable() %>%
  autofit()


## 시각화 분석
df_grip <- df_data %>%
  mutate( grip_rel = pmax(ITEM_F007, ITEM_F008, na.rm = TRUE) / ITEM_F002 * 100 ) %>%
  rename(curl_up = ITEM_F009) %>%
  select( TEST_YEAR, TEST_SEX, TEST_AGE, curl_up, grip_rel) %>%
  na.omit()

head(df_grip, 20) %>%
  flextable() %>%
  autofit()

ggplot( df_grip, aes(x = grip_rel, y = curl_up)) +
  geom_point( alpha = 0.5, color = "blue") +
  labs( title = "상대악력과 윗몸말아올리기의 관계",
        x = "상대악력(%)",
        y = "윗몸말아올리기(회)") 

ggplot( df_grip, aes(x = grip_rel, y = curl_up, color = TEST_SEX)) +
  geom_point( alpha = 0.7) +
  labs( title = "상대악력과 윗몸말아올리기의 관계 - 남녀별",
        x = "상대악력(%)",
        y = "윗몸말아올리기(회)",
        color = "성별") 

ggplot( df_grip, aes(x = grip_rel, y = curl_up)) +
  geom_point( alpha = 0.7, color = "blue") +
  labs( title = "상대악력과 윗몸말아올리기의 관계 - 남녀별",
        x = "상대악력(%)",
        y = "윗몸말아올리기(회)") +
  facet_wrap( ~ TEST_SEX)

df_bmi_1 <- df_data %>%
  filter( TEST_SEX == "남성" &  AGE_GBN == "청소년") %>%
  select( TEST_YEAR, ITEM_F018) %>%
  rename( bmi = ITEM_F018, year = TEST_YEAR)

ggplot( df_bmi_1, aes(x = year, y = bmi )) +
  geom_boxplot(outlier.alpha = 0.7) +
  labs( title = "청소년 남자의 연도별 BMI 분포 비교",
        x = "연도",
        y = "BMI")

df_bmi_2 <- df_data %>%
  filter( TEST_SEX == "여성" &  AGE_GBN == "청소년") %>%
  select( TEST_YEAR, ITEM_F018) %>%
  rename( bmi = ITEM_F018, year = TEST_YEAR)

ggplot( df_bmi_2, aes(x = year, y = bmi )) +
  geom_boxplot(outlier.alpha = 0.7) +
  labs( title = "청소년 여자의 연도별 BMI 분포 비교",
        x = "연도",
        y = "BMI")

df_bmi_3 <- df_data %>%
  filter( AGE_GBN == "성인") %>%
  select( TEST_YEAR, TEST_SEX, ITEM_F018) %>%
  rename( bmi = ITEM_F018, year = TEST_YEAR, sex = TEST_SEX)

ggplot( df_bmi_3,
        aes(x = year, y = bmi, fill = sex)) +
  geom_boxplot(outlier.alpha = 0.7, position = position_dodge(0.8)) +
  labs( title = "성인 남녀의 연도별 BMI 분포 비교",
        x = "연도",
        y = "BMI",
        fill = "성별")

## 리포트 작성 예제
df_report_wide <- df_data %>%
  filter( AGE_GBN == "청소년") %>%
  select( MEMB_SEQ, TEST_YEAR, TEST_SEX, TEST_AGE, ITEM_F009, ITEM_F010) %>%
  filter( !(is.na(ITEM_F009) & is.na(ITEM_F010)) )

head(df_report_wide, 20) %>%
  flextable() %>%
  autofit()

df_report_long <- df_report_wide %>%
  pivot_longer(
    cols = starts_with("ITEM"),
    names_to = "varname_eng",
    values_to = "value"
  ) %>%
  filter( !is.na(value))

head(df_report_long, 20) %>%
  flextable() %>%
  autofit()

df_class_level_ext <- df_class_level %>%
  rename(TEST_SEX = sex, TEST_AGE = age) %>%
  mutate( TEST_SEX = case_when(
    TEST_SEX == 1 ~ "남성",
    TEST_SEX == 2 ~ "여성")) %>%
  mutate(TEST_SEX = factor(TEST_SEX, levels = c("남성", "여성"))) %>%
  select(TEST_SEX, TEST_AGE, varname_eng,Q30, Q50, Q70)

head(df_class_level_ext, 20) %>%
  flextable() %>%
  autofit()


df_report_merged <- df_report_long %>%
  left_join( df_class_level_ext,
             by = c("TEST_SEX", "TEST_AGE", "varname_eng"))

head(df_report_merged, 20) %>%
  flextable() %>%
  autofit()

df_report_class <- df_report_merged %>%
  mutate( class = case_when( value < Q30 ~ "4등급",
                             value >= Q30 & value < Q50 ~ "3등급",
                             value >= Q50 & value < Q70 ~ "2등급",
                             value >= Q70 ~ "1등급")) %>%
  mutate( class = factor(class, levels = c("1등급", "2등급", "3등급", "4등급"))) %>%
  select( MEMB_SEQ, TEST_YEAR, TEST_SEX, TEST_AGE, class)

head(df_report_class, 20) %>%
  flextable() %>%
  autofit()

table_class_1 <- df_report_class %>%
  count(TEST_YEAR, class, name = "freq")

table_class_1 %>%
  flextable() %>%
  autofit()

table_class_2 <- table_class_1 %>%
  group_by(TEST_YEAR) %>%
  mutate( percent = freq / sum(freq) * 100 ) %>%
  ungroup()

table_class_2 %>%
  flextable() %>%
  autofit()

table_class_2 <- table_class_2 %>%
  mutate( percent = round(percent, 2)) %>%
  rename( 년도 = TEST_YEAR, 등급 = class, 도수 = freq, 비율 = percent)

table_class_2 %>%
  flextable() %>%
  autofit()

table_class_3 <- table_class_2 %>%
  pivot_wider(
    names_from = 등급,
    values_from = c(도수, 비율),
    names_glue = "{.value}_{등급}"
  ) %>%
  mutate(총인원 = rowSums(across(contains("도수")), na.rm = TRUE)) %>%
  relocate( 총인원, .after = 년도)

table_class_3 %>%
  flextable() %>%
  autofit()

ggplot(table_class_2, aes(x = 년도, y = 비율, fill = 등급)) +
  geom_bar(stat = "identity") +
  geom_text(
    aes(label = sprintf("%.1f%%", 비율)),
    position = position_stack(vjust = 0.5),
    size = 3
  ) +
  labs(title = "연도별 청소년 근지구력 등급 분포",
       x = "연도", y = "비율(%)", fill = "등급")

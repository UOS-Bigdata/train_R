## 패키지 불러오기 ##
library(dplyr)
library(ggplot2)

# 4. ggplot2의 이해와 활용용
plot(mpg$displ, mpg$hwy,
     main = "base plot: displ vs hwy",
     xlab = "displ", ylab = "hwy",
     pch = 20, col = "blue")

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point() +
  labs(title = "ggplot2: displ vs hwy")

## 4.1 ggplot2의 기본 구조
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point()

## 4.2 미적요소
ggplot(mpg, aes(x = displ, y = hwy, color = class)) +
  geom_point()

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.5)

## 4.3 레이어 추가 
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.6) +
  geom_smooth(se = TRUE)

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm", se = TRUE)

## 4.4 facet_wrap
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.6) +
  facet_wrap(~ class)

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.6) +
  facet_wrap(~ drv)

## 4.5 범주형 그래프
ggplot(mpg, aes(x = class)) +
  geom_bar()

ggplot(mpg, aes(x = class)) +
  geom_bar() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggplot(mpg, aes(x = class, y = hwy)) +
  geom_boxplot() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

ggplot(mpg, aes(x = class, y = hwy)) +
  geom_boxplot(outlier.alpha = 0.2) +
  geom_jitter(width = 0.15, alpha = 0.4) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

## 4.6 집계 후 시각화
mpg_sum <- mpg %>%
  group_by(class) %>%
  summarise(
    mean_hwy = mean(hwy),
    n = n(),
    .groups = "drop"
  )

mpg_sum

ggplot(mpg_sum, aes(x = class, y = mean_hwy)) +
  geom_col() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


ggplot(mpg_sum, aes(x = reorder(class, mean_hwy), y = mean_hwy)) +
  geom_col() +
  coord_flip() +
  labs(
    x = "class",
    y = "평균 고속도로 연비(mean hwy)",
    title = "차종별 평균 고속도로 연비(정렬)"
  )

## 4.7 라벨
ggplot(mpg, aes(x = displ, y = hwy, color = drv)) +
  geom_point(alpha = 0.7) +
  labs(
    title = "배기량과 고속도로 연비의 관계",
    subtitle = "구동방식(drv)별로 색상 구분",
    x = "배기량(displ)",
    y = "고속도로 연비(hwy)",
    color = "구동방식"
  )

## 4.8 테마
ggplot(mpg, aes(x = displ, y = hwy, color = class)) +
  geom_point(alpha = 0.7) +
  theme_minimal()

## 4.9 스케일
ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.7) +
  scale_y_continuous(limits = c(10, 40))

ggplot(mpg, aes(x = displ, y = hwy)) +
  geom_point(alpha = 0.7) +
  scale_x_log10()

## 4.10 저장
p <- ggplot(mpg, aes(x = displ, y = hwy, color = drv)) +
  geom_point(alpha = 0.7) +
  theme_minimal()

p


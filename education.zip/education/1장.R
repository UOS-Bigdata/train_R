# 1. R의 기초

## 1.1 연산

1 + 2
1 - 2
2 * 2
2 / 2

# 나머지 #
3 %% 2

# 제곱 #
2 ^ 2
2 ** 2

# 비교연산 #
3 > 2      
5 == 10    
4 != 4     
7 <= 9    

## 1.2 변수
x <- 2
y = 5

# 변수 제거 #
x <- 10
ls()
rm(x) 

## 1.3 데이터 타입
# numeric #
x <- 3.14
is.numeric(x)   

# integer #
x <- 10L
is.integer(x)  
is.numeric(x)   

# character #
name <- "Alice"
class(name)       

gender <- factor("female", levels = c("male", "female"))
class(gender)   

# logical #
a <- TRUE
b <- FALSE

class(a)   

TRUE + TRUE   
TRUE * 5 

## 1.4 벡터
num_vec <- c(1, 2, 3, 4, 5)
char_vec <- c("apple", "banana", "cherry")
log_vec <- c(TRUE, FALSE, TRUE, TRUE)


# coercion #
v <- c(1, 2, "김", TRUE)
v
class(v)    

a <- c(1, 2, 3)
b <- c(4, 5, 6)

a + b  
a - b  
a * b   
a / b   

# 재활용 규칙 #
a <- c(1, 2, 3, 4)
b <- c(10, 100)

a + b

a <- c(1, 2, 3)
a + 10    
a * 2      

# 인덱싱 #
x <- c(10, 20, 30, 40, 50)

x[1]       
x[3]       
x[c(2, 4)]

x[-1]   
x[-c(2, 5)]

x <- c(5, 10, 15, 20)
x[c(FALSE, FALSE, TRUE, TRUE)]

x > 10          
x[x > 10]       

# 범주형 벡터
gender <- c("male", "female", "male", "female", "female")
gender <- as.factor(gender)
gender

as.numeric(gender)

# 벡터 함수 #
x <- c(10, 20, 30, 40)

length(x)
sum(x)
mean(x)
max(x)
min(x)

sort(x)
sort(x, decreasing = TRUE)

# 결측값 #
x <- c(1, 2, NA, 4)
mean(x)             
mean(x, na.rm = TRUE)

y <- NULL
length(y)     

z <- c(1, NULL, 3)  

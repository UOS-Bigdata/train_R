## 패키지 불러오기 ##
library(dplyr)
library(ggplot2)

# 2. 데이터프레임

## 2.1 데이터프레임의 생성
x <- 10:1
y <- -4:5
q <- c("Hockey", "Football", "Baseball", "Curling", "Rugby", 
       "Lacrosse", "Basketball", "Tennis", "Cricket", "Soccer")

df <- data.frame(x, y, q)
df <- data.frame(Fisrt = x, Second = y, Sport = q)

## 2.2 데이터프레임 정보 요약
data <- mpg

nrow(mpg)
ncol(mpg)
dim(mpg)

dim(mpg)[1] == nrow(mpg)

names(mpg)
str(mpg)

head(mpg)
tail(mpg)

View(mpg)

# 변수 선택 #
head(mpg$cty)

# 2.3 데이터프레임 주요 함수
table(mpg$manufacturer)

colSums(mpg) 
colMeans(mpg)

mpg_numeric <- mpg %>% 
  select(where(is.numeric))

colSums(mpg_numeric)
colMeans(mpg_numeric)

summary(mpg_numeric)

# 2.4 데이터프레임 인덱싱
mpg[2, 3]

mpg[3, 2:3]
mpg[3, c(2, 3)]

mpg[, 3]
mpg[, 2:3]
mpg[, c("model", "displ")]         

mpg$model == "a4"
mpg[mpg$model == "a4", ] 

mpg[, 1]
mpg[, "manufacturer"]

mpg$manufacturer

# 복합조건 #
mpg[mpg$manufacturer == "audi" & mpg$cty >= 20, ]
mpg[mpg$class == "compact" | mpg$class == "midsize", ]
mpg[mpg$manufacturer == "audi", c("model", "year")]


## 예제 ##
# 예제 1
audi_cars <- mpg[mpg$manufacturer == "audi", ]
mean(audi_cars$cty)
mean(mpg[mpg$manufacturer == "audi", "cty"]$cty)

# 예제 2
# SUV 차량의 고속도로 연비 평균
suv_hwy <- mpg[mpg$class == "suv", "hwy"]$hwy
mean(suv_hwy)

# Compact 차량의 고속도로 연비 평균
compact_hwy <- mpg[mpg$class == "compact", "hwy"]$hwy
mean(compact_hwy)

# 예제 3
big_engine_cars <- mpg[mpg$year >= 2000 & mpg$displ >= 4.0, ]
summary(big_engine_cars$cty)

# 예제 4
us_cars <- mpg[mpg$manufacturer == "chevrolet" | mpg$manufacturer == "ford", ]
nrow(us_cars)
table(us_cars$manufacturer)

# 예제 5
cyl4_cars <- mpg[mpg$cyl == 4, ]
max(cyl4_cars$hwy)
min(cyl4_cars$hwy)

# 2.5 데이터프레임 합치기
students <- data.frame(id = c(1, 2, 3), name = c("Kim", "Lee", "Park"))
scores <- data.frame(id = c(1, 3, 4), score = c(90, 85, 70))

inner_join(students, scores, by = "id")
left_join(students, scores, by = "id")
right_join(students, scores, by = "id")

# cbind(), rbind() #
new_row <- data.frame(
  Sepal.Length = 5.1,
  Sepal.Width = 3.5,
  Petal.Length = 1.4,
  Petal.Width = 0.2,
  Species = "setosa"
)

iris_extended <- rbind(iris, new_row)
nrow(iris_extended) 
tail(iris_extended)

New_Var <- 1:150 
iris_with_new <- cbind(iris, New_Var)
head(iris_with_new)

# 2.6 데이터프레임 서브세팅
iris[iris$Species == "setosa", ]
iris[iris$Sepal.Length > 5, ]

subset(iris, Species == "setosa")
subset(iris, Sepal.Length > 5)

subset(iris, Species == "setosa" | Species == "virginica")
subset(iris, Species == "setosa" & Sepal.Length > 5)

iris[iris$Species == "setosa" | iris$Species == "virginica", "Sepal.Length"]

